import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glow',
  templateUrl: './glow.component.html',
  styleUrls: ['./glow.component.css']
})
export class GlowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
