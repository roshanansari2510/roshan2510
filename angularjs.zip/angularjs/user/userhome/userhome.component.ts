import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service'; 
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {
  public productList:any;
  constructor(private api : ApiService, private cartService : CartService) { }

  ngOnInit(): void {
    this.api.getProducts()
    .subscribe((res:any)=>{
      this.productList=res;

      this.productList.array.forEach((a:any) => {
        Object.assign(a,{quantity:1,total:a.price});
      });
    })
  
  }
  addtocart(pizza: any){
    this.cartService.addtoCart(pizza)
  }
}  
  