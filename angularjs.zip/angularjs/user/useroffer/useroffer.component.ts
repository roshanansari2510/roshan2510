import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useroffer',
  templateUrl: './useroffer.component.html',
  styleUrls: ['./useroffer.component.css']
})
export class UserofferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
